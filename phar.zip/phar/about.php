
<html>
<head>
	<title>about us</title>
	<link rel="stylesheet"type="text/css"href="styles.css">

</head>
<body>
<header>
	<hgroup>
		<h1>Sample Project</h1>
	</hgroup>
	<nav>
		<ul>
		<li><a href="login.php"target="_blank">Home</a></li>
		<li><a href="contacts.php"target="_blank">Contact</a></li>
		<li><a href="#"target="_blank">About us</a></li>	
		</ul>
	</nav>
</header>
<section>
	<article>
	<h1>RGUKT</h1 >
	<img src="rgukt.jpg" alt="rgukt" width="150" height="100">
	<p>RAJIV GANDI UNIVERSITY OF KNOWLEDGE TECHNOLOGIES</p>
	<p>AP IIIT</p>
	<p>RK VALLEY</p>
	<p>KADAPA</p>
	</article>
	
</section>

</body>

</html>
