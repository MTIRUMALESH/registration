<html>
<head>
<title>Contacts</title>

<style>

	body{
		background:url(f2.jpg);
		background-size:cover;
		margin:0;
		}
		li{
			text-decoration:none;
			color:white;
			padding:10px;
		}

	div.one{
		border-width:5px;
		border-style:double;
		border-color:green;
		}

	hr{
		border-style:hidden;
		}
	img{
	margin:10px;
	border-style:solid;
	border-width:3px;
	border-color:blue;
		}
		img:hover{
	border-radius:10px;
	box-shadow:2px 2px;
	border:2px solid blue;
}
</style>

</head>
<body>
<div class="one">
	<ul>
	<li>NaMe :- Tirumalesh</li>
	<img src="user.jpg" alt="" width="150" height="100"/>
	<li>CoNtAcT :- +919441671504</li>
	</ul>
</div>

<hr>

</body>
</html>
